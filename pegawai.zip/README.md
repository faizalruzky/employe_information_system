simpeg
=========

Simple Employee Management Applications

Just simple employee management application with CodeIgniter and Twitter Bootstrap
